package com.medhallc.myquiz;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class CategoriesActivity extends AppCompatActivity {

    public static final String SELECTED_CATEGORY = "selectedCategory";

    private FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);

        final FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();

        if (firebaseUser.isEmailVerified() == false) {
            Toast.makeText(getApplicationContext(),"please verify your email",
                    Toast.LENGTH_SHORT).show();
        }

            Button buttonGeography = findViewById(R.id.buttonGeography);
            buttonGeography.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startQuiz(Constants.GEOGRAPHY);
                }
            });

            Button buttonMaths = findViewById(R.id.buttonMaths);
            buttonMaths.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startQuiz(Constants.MATHS);
                }
            });

            Button buttonProgramming = findViewById(R.id.buttonProgramming);
            buttonProgramming.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startQuiz(Constants.PROGRAMMING);
                }
            });

            Button buttonScience = findViewById(R.id.buttonScience);
            buttonScience.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startQuiz(Constants.SCIENCE);
                }
            });

            Button buttonGeneralKnowledge = findViewById(R.id.buttonKnowledge);
            buttonGeneralKnowledge.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startQuiz(Constants.GENERAL_KNOWLEDGE);
                }
            });

            Button buttonSports = findViewById(R.id.buttonSports);
            buttonSports.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startQuiz(Constants.SPORTS);
                }
            });

            Button buttonHealth = findViewById(R.id.buttonHealth);
            buttonHealth.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startQuiz(Constants.HEALTH);
                }
            });

            Button buttonEconomy = findViewById(R.id.buttonEconomy);
            buttonEconomy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startQuiz(Constants.ECONOMY);
                }
            });
        }

    private void startQuiz(String selectedCategory) {
        Intent intent = new Intent(CategoriesActivity.this,Quiz.class);
        intent.putExtra(SELECTED_CATEGORY,selectedCategory);
        startActivity(intent);
    }
}

