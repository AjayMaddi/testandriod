package com.medhallc.myquiz;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * The QuestionsDataList class implements the how to retrieve data from json file
 * and converted into object and then added to array list.
 */
public class QuestionsDataList {


    List<Question> questionList = new ArrayList<>();

    Context mContext;

    /**
     * Returns the instance of an QuestionsDataList class.
     *
     * @param context used to access the application specific resources and classes.
     */
    public QuestionsDataList(Context context) {
        mContext = context;
    }

    /**
     * Returns the list of questions for the user selected category.
     *
     * @param selectedCategory the string representation of the selected category name.
     * @return the list of questions.
     */
    public List<Question> getQuestions(String selectedCategory) {
        String json_string;
        try {
            InputStream inputStream = mContext.getAssets().open(selectedCategory+".json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();


            json_string = new String(buffer, "UTF-8");
            JSONArray jsonArray = new JSONArray(json_string);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                Question question = new Question();
                if (selectedCategory.equalsIgnoreCase(jsonObject.getString("category"))) {
                    question.setQuestion(jsonObject.getString("question"));
                    question.setOption1(jsonObject.getString("option1"));
                    question.setOption2(jsonObject.getString("option2"));
                    question.setOption3(jsonObject.getString("option3"));
                    question.setOption4(jsonObject.getString("option4"));
                    question.setAnswerNumber(Integer.parseInt(jsonObject.getString(
                            "answernumber")));
                    question.setCategory(jsonObject.getString("category"));

                    questionList.add(question);
                }

            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return questionList;
    }
}
