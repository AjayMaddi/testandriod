package com.medhallc.myquiz;

public interface Constants {

    String GEOGRAPHY = "geography";
    String MATHS = "maths";
    String PROGRAMMING = "programming";
    String SCIENCE = "science";
    String GENERAL_KNOWLEDGE = "generalknowledge";
    String SPORTS = "sports";
    String HEALTH = "health";
    String ECONOMY = "economy";

}
