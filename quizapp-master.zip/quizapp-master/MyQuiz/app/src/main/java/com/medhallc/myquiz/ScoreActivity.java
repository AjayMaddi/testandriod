package com.medhallc.myquiz;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ScoreActivity extends AppCompatActivity {

    private TextView textViewYourScore,logoutProfile;
    private RadioButton correctAnswerButton;
    private RadioButton wrongAnswerButton;
    private int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        AdView adView = findViewById(R.id.adViewScore);
        MobileAds.initialize(this);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);

        BottomNavigationView bottomNavigationView =findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(navigationItemSelectedListener);

        textViewYourScore = findViewById(R.id.finalScore);
        wrongAnswerButton = findViewById(R.id.wrong_answers);
        correctAnswerButton = findViewById(R.id.correct_answers);
        loadScore();
    }

    private void loadScore() {
        Intent intent = getIntent();
        score = intent.getIntExtra("Score",0);
        int wrongAnswers = 10 - score;
        textViewYourScore.setText("Final score: "+score);
        correctAnswerButton.setText("Correct answers:"+score);
        wrongAnswerButton.setText("Wrong answers:"+wrongAnswers);
    }

    private void shareIt() {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        String sharedMessage = "Yay ! I scored " + score + " in this awesome quiz.checkout this " +
                "app at https://play.google.com/store/apps/details?id=com.medhallc.myquiz";
        shareIntent.putExtra(Intent.EXTRA_TEXT,sharedMessage);
        startActivity(Intent.createChooser(shareIntent,"choose one"));
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navigationItemSelectedListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.navigation_home:
                            startActivity(new Intent(getApplicationContext(),
                                    CategoriesActivity.class));
                            overridePendingTransition(0,0);
                            return true;

                        case R.id.navigation_share:
                            shareIt();
                            return true;

                        case R.id.navigation_profile:
                            startActivity(new Intent(getApplicationContext(),Profile.class));
                            return true;

                        case R.id.navigation_play_again:
                            Intent intent = new Intent(ScoreActivity.this,
                                    CategoriesActivity.class);
                            startActivity(intent);
                            return true;

                    }
                    return true;
                }
            };
}
